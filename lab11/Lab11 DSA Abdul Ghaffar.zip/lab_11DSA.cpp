/*

Abdul Ghaffar Kalhoro
Lab 11
comparison between insertion and merge sort
for n = 1 lac

*/

#include<iostream>
#include<stdlib.h>
#include<stdio.h>
#include <fstream>
#include <string>
#include <ctime>

using namespace std;
#define nom 100000
void mergeSort(int arr[], int l, int right);
void merge(int arr[], int l, int m, int right);

void insertionSortA(int arr[], int sizes) {

	int key;
	int i;
	for (int j = 1; j<sizes; j++) {
		key = arr[j];
		for (i = j - 1; i >= 0 & arr[i]>key; i--)
			arr[i + 1] = arr[i];
		arr[i + 1] = key;
	}
}

/*
	~~function mergesort
parameters:  arr, left, right
where: arr is the array of numbers 
left represent the left index of subarray of arr
and so as right for right index
 */

void mergeSort(int arr[], int left, int right)
{	if (left < right)
	{
		// Same as (left+right)/2, but avoids overflow for
		// large left and h
		int m = left + (right - left) / 2;
		// Sort first and second halvesLfT
		mergeSort(arr, left, m);
		mergeSort(arr, m + 1, right);
		merge(arr, left, m, right);
	}
}


void merge(int arr[], int left, int m, int right)
{
	int a, b, c;
	int* LfT = NULL;
	int* RiT = NULL;
	int n1 = m - left + 1;
	int n2 = right - m;

	// creating temp arrays 
	LfT = new int[n1];
	RiT = new int[n2];

	//Copying data to temp arrays LfT[] and RiT[]
	for (a = 0; a < n1; a++)
		LfT[a] = arr[left + a];
	for (b = 0; b < n2; b++)
		RiT[b] = arr[m + 1 + b];

	// Merging the temp arrays values which are sorted back into arr[left..right]
	a = 0; // starting index of first subarray
	b = 0; // starting index of second subarray
	c = left; // starting index of merged subarray
	while (a < n1 && b < n2)
	{
		if (LfT[a] <= RiT[b])
		{
			arr[c] = LfT[a];
			a++;
		}
		else
		{
			arr[c] = RiT[b];
			b++;
		}
		c++;
	}

	/* If there are remaining elements in Lft[], then copy those elements */
	while (a < n1)
	{
		arr[c] = LfT[a];
		a++;
		c++;
	}
	/* If there are remaining elements in RfT[], then copy those elements */
	while (b < n2)
	{
		arr[c] = RiT[b];
		b++;
		c++;
	}
}
//main function
int main()
{
	srand(time(NULL));
	int myArray[nom];
	int j = 0;
	string num;
	int temp_num;
	int i = 0;
	int input1;
	int choice;
	double elapsed_seconds = -1;
	//choice menu

	cout << "Available choices:  "<<endl;
	cout << "1)Random numbers in Ascending order "<<endl
		<< "2)Random numbers"<<endl
		<< "3)Random numbers in descending order"<<endl;
	cout << "Your choice:  ";
	//choice input
	cin >> input1;
	if (input1 == 1)//condition for given choice
	{
		ifstream myfile1("SortedRandomNumbersA.txt");
		if (myfile1.is_open()) {
			int i = 0;
			while (getline(myfile1, num)) {
				temp_num = stoi(num);
				myArray[i] = temp_num;
				i++;
			}
			myfile1.close();

			cout << "enter choice ::1 for insertion:: 2 for merge sort::";
			cin >> choice;
			if (choice == 1){
				cout << "~~Insertion Sort~~ \n";
				cout << "~~complexity for sorted random numbers in ascending order~~ \n";

				clock_t begin = clock();
				insertionSortA(myArray, nom);
				clock_t end = clock();

				elapsed_seconds = double(end - begin) / CLOCKS_PER_SEC * 1000;
		
			}
			else if(choice == 2){
				cout << "~~Merge Sort~~ \n";
				cout << "~~complexity for sorted random numbers in ascending order~~ \n";
				clock_t begin = clock();
				mergeSort(myArray, 0, nom - 1);
				clock_t end = clock();

				elapsed_seconds = double(end - begin) / CLOCKS_PER_SEC * 1000;
			
			
			}
		}
	}
	else if (input1 == 2){
		
		ifstream myfile2("RandomNumbers.txt");
		if (myfile2.is_open()) {
			int i = 0;
			while (getline(myfile2, num)) {
				temp_num = stoi(num);
				myArray[i] = temp_num;
				i++;
			}
			myfile2.close();
			cout << "enter choice ::1 for insertion:: 2 for merge sort::";
			cin >> choice;
			if (choice == 1){
				cout << "~~Insertion sort~~ \n";
				cout << "~~complexity for random numbers~~ \n";

				clock_t begin = clock();
				insertionSortA(myArray, nom);
				clock_t end = clock();
				elapsed_seconds = double(end - begin) / CLOCKS_PER_SEC * 1000;
			}//end inner if condition
		
			else if(choice == 2){
				cout << "~~Merge sort~~ \n";
				cout << "~~complexity for random numbers~~ \n";

				clock_t begin = clock();
				mergeSort(myArray, 0, nom - 1);
				clock_t end = clock();
				elapsed_seconds = double(end - begin) / CLOCKS_PER_SEC * 1000;
			}
		}
	}

	else if (input1 == 3){
		
		ifstream myfile2("SortedRandomNumbersD.txt");
		if (myfile2.is_open()) {
			int i = 0;
			while (getline(myfile2, num)) {
				temp_num = stoi(num);
				myArray[i] = temp_num;
				i++;
			}
			myfile2.close();

			cout << "enter choice ::1 for insertion:: 2 for merge sort::";
			cin >> choice;
			if (choice == 1){
				cout << "~~Insertion sort~~ \n";
				cout << "~~complexity for sorted random numbers in descending~~ \n";
				clock_t begin = clock();
			insertionSortA(myArray, nom);
			clock_t end = clock();
			elapsed_seconds = double(end - begin) / CLOCKS_PER_SEC * 1000;
			}
			else if(choice == 2){
			
				cout << "~~Merge sort~~ \n";
				cout << "~~complexity for sorted random numbers in descending~~ \n";
				clock_t begin = clock();
				mergeSort(myArray, 0, nom - 1);

				clock_t end = clock();
				elapsed_seconds = double(end - begin) / CLOCKS_PER_SEC * 1000;
			
			
			}
		}//end myfile2
	}//end else if
if (elapsed_seconds != -1){
			cout << endl << "sorting Time complexity is : " << elapsed_seconds << " millisecs."
				<< endl;
		}
else{
	cout << "wrong choice entered....";
	cout << endl << "exiting program....";
}

	
cout << endl << endl;
	return 0;

}