//Abdul Ghaffar Kalhoro
#include<iostream>
#include<string>
using namespace std;
using namespace std;
# define length_PostFix 50     /* total number of characters in input expression*/
int stackArray[100];
int current = -1;

class stack{
public:
	void push(char value){
		stackArray[++current] = value;
	}

	int pop(){
		return stackArray[current--];
	}

	void peek(){

		cout << endl << "The top element of stack is: " << stackArray[current];
	}
	int top(){
		return stackArray[current];
	}

	bool isEmpty(){
		return (current == -1);
	}
	bool isFull(){

		return (current > 100);
	}


	bool pairing(char open, char close)
	{
		if (open == '(' && close == ')')
			return true;
		else if (open == '{' && close == '}')
			return true;
		else if (open == '[' && close == ']')
			return true;
		return false;
	}


	bool IsBalExpression(string exp)
	{
		for (int counter = 0; counter < exp.length(); counter++)
		{
			if (exp[counter] == '(' || exp[counter] == '{' || exp[counter] == '[')
				push(exp[counter]);
			else if (exp[counter] == ')' || exp[counter] == '}' || exp[counter] == ']')
			{
				if (isEmpty() || !pairing(top(), exp[counter]))
					return false;
				else
					pop();
			}
		}
		return isEmpty() ? true : false;
	}
};
	





int main(void){
	char array[length_PostFix];
	int x;

	stack obj;
	string expression;
	cout << "Enter any Expression  "; // input expression from STDIN/Console
	getline(cin, expression);
if (obj.IsBalExpression(expression)){
		cout << "This expression is correct";
	}
	else{
		cout << "The expression is not correct";
	}
	getchar();
	getchar();
	return 0;

}