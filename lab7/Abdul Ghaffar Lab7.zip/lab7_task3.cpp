//task-3
/*
Infix to postfix conversion in C++
Input Postfix expression must be in one digit format.
Only '+'  ,  '-'  , '*', '/' and '^' operators are expected.
*/
#include<iostream>
#include<stack>
#include<string>

using namespace std;
int stackArray[100];
int current = -1;

void push(char value){
	stackArray[++current] = value;

}

int pop(){
	return stackArray[current--];
}

void peek(){

	cout << endl << "The top element of stack is: " << stackArray[current];
}
int top(){
	return stackArray[current];
}

bool isEmpty(){
	return (current == -1);
}
bool isFull(){

	return (current > 100);
}

//postfix evaluation

void postFix(string postfix)
{

	int i;
	int value;
	int no1, no2;
	int n1;

	// evaluate postfix expression 
	for (i = 0; postfix[i] != '\0'; i++)
	{
		if (postfix[i] == ' ' || postfix[i] == ','){
			continue;
		}
		else if (isdigit(postfix[i]))
		{
			/* stack character - '0' is used for getting digit rather than ASCII code of digit */
			n1 = postfix[i] - '0';
			push(n1);

		}
		else if (postfix[i] == '+' || postfix[i] == '-' || postfix[i] == '*' || postfix[i] == '/' || postfix[i] == '^')
		{	no1 = pop();
			no2 = pop();

			//operator matching
			switch (postfix[i])
			{

			case '+':
				value = no2 + no1;
				break;
			case '-':
				value = no2 - no1;
				break;

			
			case '*':
				value = no2 * no1;
				break;

			case '/':
				value = no2 / no1;
				break;
			case '^':
				value = pow(no2, no1);
				break;
			}
			push(value);
		}//end elseif
	}//end for loop
	cout << "\nResult of postfix expression: " << pop()<<endl;

}



// Function to verify whether a character is english letter or numeric digit. 
// We are assuming in this solution that operand will be a single character
bool IsOperand(char C)
{
	if (C >= '0' && C <= '9') 
		return true;
	if (C >= 'a' && C <= 'z') 
		return true;
	if (C >= 'A' && C <= 'Z')
		return true;
	return false;
}

// Function to verify whether a character is operator symbol or not. 
bool IsOperator(char C)
{
	if (C == '+' || C == '-' || C == '*' || C == '/' || C == '^')
		return true;
	else
	return false;
}

// Function to verify whether an operator is right associative or not. 
int IsRightAssociative(char value)
{
	if (value == '^')
		return true;
	return false;
}

int GetOperatorWeight(char value)
{
	int strength = -1;
	switch (value)
	{
	case '+':
	case '-':
		strength = 1;
	case '*':
	case '/':
		strength = 2;
	case '^':
		strength = 3;
	}
	return strength;
}
 
int Hprecedence(char op1, char op2)
{
	int op1Weight = GetOperatorWeight(op1);
	int op2Weight = GetOperatorWeight(op2);

	if (op1Weight == op2Weight)
	{
		if (IsRightAssociative(op1))
			return false;
		else 
			return true;
	}
	return op1Weight > op2Weight ? true : false;
}
// Function to evaluate Postfix expression
string IfixToPfix(string expression)
{

	string postfix = ""; // Initialize postfix as empty string.
	for (int i = 0; i< expression.length(); i++) {

		// Scanning each character from left. 
		// If character is a delimitter, move on. 
		if (expression[i] == ' ' || expression[i] == ','){
			postfix += ' ';
			continue;
		}
		// If character is operator, pop two elements from stack, perform operation and push the result back. 
		else if (IsOperator(expression[i]))
		{

			while (!isEmpty() && top() != '(' && Hprecedence(top(), expression[i]))
			{
				postfix += top();
				pop();
			}

			push(expression[i]);
		}
		// Else if character is an operand

		else if (IsOperand(expression[i]))
		{
			postfix += expression[i];
		}

		else if (expression[i] == '(')
		{
			push(expression[i]);
		}

		else if (expression[i] == ')')
		{
			while (!isEmpty() && top() != '(') {
				postfix += top();
				pop();
			}
			postfix += ' ';
			pop();
		}

	}	//end for loop

	while (!isEmpty()) {
		postfix += top();
		pop();
	}

	return postfix;
}

int main()
{
	string expression;
	cout << "Enter Infix Expression \n";
	getline(cin, expression);
	cout << endl << expression;
	string postfix = IfixToPfix(expression);
	cout << "The postfix evaluation is: " << postfix << "\n";
	postFix(postfix);
	getchar();
	getchar();
}