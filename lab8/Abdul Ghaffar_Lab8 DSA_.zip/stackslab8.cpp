/*
NAME	:	Abdul Ghaffar Kalhoro
CLASS   :	BSCS-6C
Reg no	:	194699




*/



#include <iostream>
using namespace std;

// making a Disk with a data like the node  , 

// which is an element of the stack

class Disk
{
public:
	int data;
	Disk* next;
};

class Stack
{
public:
	int size;
	Disk* current;
	char name;

	//declaring a constructor
	Stack(char temp)
	{
		size = 0;
		current = NULL;
		name = temp;
	}
	bool isEmpty();
	int getSize();
	bool push(int);
	bool pop();
	void  moveDisk(Stack *source, Stack *dest); // function for moving a Disk from source to destionation
};


bool Stack::isEmpty()
{
	if (getSize() == 0)
		return true;
	return false;
}

int Stack::getSize()
{
	return size;
}
bool Stack::push(int element)
{
	Disk*    temp;
	temp = new Disk;
	if (current == NULL)
	{
		temp->next = NULL;
	}
	else
	{
		temp->next = current;
	}
	temp->data = element;
	this->current = temp;

	size++;
	return false;
}
bool Stack::pop()
{
	if (isEmpty())
	{
		cout << "\nThe Stack is Empty:\n";
		return false;
	}
	else
	{
		current = current->next;
		size = size--;
	}
	return true;
}


void createSourceStack(Stack *source, int disks_number)  // pushing number of disks on source stack
{
	for (int i = disks_number; i>0; i--)
	{
		source->push(i);
	}

}
void Stack::moveDisk(Stack *source, Stack *dest) // movinng a Disk from source to destionation
{
	dest->push(source->current->data);
	source->pop();
	cout << name << " --> " << dest->name << endl;

}
void  towerOfHanoi(int no_of_disks, Stack *source, Stack *destination, Stack  *temporary) // move N Disks from source to destination
{
	if (no_of_disks == 1)
		source->moveDisk(source, destination);

	else
	{
		towerOfHanoi(no_of_disks - 1, source, temporary, destination);//move n-1 Disks from source to auxxilary 

		source->moveDisk(source, destination);                //move nTH Disk from source to destination 

		towerOfHanoi(no_of_disks - 1, temporary, destination, source);//move n-1 Disks from auxillary to destination
	}
}
int main()
{
	Stack *source, *destination, *auxillary;    // declaring three different objects of Stack class

	//Stacks required for the 3 Stacks source destination and auxillary
	source = new Stack('A');

	destination = new Stack('B');

	auxillary = new Stack('C');

	//take number of Disks from user
	int disks_number;
	cout << "\t~~tower of haboi~~" << endl;
	cout << "Please Enter number of Disks in the source Stack\n\nNumber of source disks =   ";
	cin >> disks_number;

	//inserting the Disks into the source Stack 
	createSourceStack(source, disks_number);

	cout << "\nA = Source Tower\nB = Destination tower\nC = spare tower\n--> = to\n" << endl;
	towerOfHanoi(disks_number, source, destination, auxillary);
	cout << "\n\n";

	system("pause");
	return 0;
}
