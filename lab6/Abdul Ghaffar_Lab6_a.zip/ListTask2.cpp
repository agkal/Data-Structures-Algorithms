

//task2
#include <iostream>
using namespace std;

struct node
{
	int data;
	node *next;
};

class List
{
private:
	node *head, *tail; // node type variables
public:
	List() //constructor
	{
		head = NULL;
		tail = NULL;
	}

	void appendNode(int number)
	{
		node *temp = new node; //temp is object of node type
		temp->data = number;
		temp->next = NULL;
		if (head == NULL)
		{
			head = temp;
			tail = temp;
			temp = NULL;
		}
		else
		{
			tail->next = temp;
			tail = temp;
		}
	}


	//insert at start
	void InsertStart(int number)
	{
		node *temp = new node;
		temp->data = number;
		temp->next = head;
		head = temp;
	}

	//Function to insert at the end
	void InsertLast(int number)
	{
		node *temp = new node;
		temp->data = number;
		temp->next = NULL;

		if (head == NULL)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			tail->next = temp;
			tail = tail->next;
		}
	}

	//function to insert node in between of list
	void InsertParticular(int positn, int value)
	{

		node *temp = new node;
		node *current = new node;
		node *prev = new node;

		current = head;

		for (int counter = 1; counter < positn; counter++) {
			prev = current;
			current = current->next;
		}

		temp->data = value;
		prev->next = temp;
		temp->next = current;
	}

	//function to delete first node
	void deleteBegin()
	{
		node *temp = new node;
		temp = head;
		head = head->next;
		delete temp;
	}

	//function to delete last node
	void deleteLast()
	{
		node *current = new node;
		node *prev = new node;
		current = head;
		while (current->next != NULL)
		{
			prev = current;
			current = current->next;
		}
		tail = prev;
		prev->next = NULL;
		delete current;
	}

	//function to delete particular node of list
	void deletePart(int pos)
	{
		node *current = new node;
		node *prev = new node;
		current = head;
		for (int i = 1; i < pos; i++)
		{
			prev = current;
			current = current->next;
		}
		if (pos == 1)
			deleteBegin();
		prev->next = current->next;
	}


	// function to display
	void display()
	{
		node *temp = new node;
		temp = head;
		if (temp == NULL){
			cout << "Nothing to display";
		}
		while (temp != NULL)
		{
			cout << temp->data << "\t";
			temp = temp->next;
		}
	}

	int searchpos(int val){
		node *temp = new node();
		temp = head;
		for (int count = 1; count <val; count++){
			temp = temp->next;
		}
		return temp->data;
	}
};

int main(){

	List L1;
	List L2;
	List L3;

	L1.appendNode(5);
	L1.appendNode(10);
	L1.appendNode(15);
	L1.appendNode(20);
	L1.appendNode(25);
	L1.appendNode(30);
	L1.appendNode(35);
	L1.appendNode(40);
	cout << "L1:   ";
	L1.display();
	cout << endl;
	int i = 1;
	while (i <= 4){


		L2.appendNode(L1.searchpos(i));
		L1.deletePart(i);
		i = i + 1;
	};
	cout << endl;
	cout << "After deleting odd elements: ";
	cout << endl;
	cout << "L1:   ";
	L1.display();
	cout << endl;
	cout << "L2:  ";
	L2.display();
	i = 1;
	while (i <= 4){


		L3.appendNode(L1.searchpos(1));
		L1.deletePart(1);
		i = i + 1;
	};
	
	cout << endl;
	cout << "After deleting all elements from L1:";
	cout << endl;
	cout << "L1:  ";
	L1.display();

	cout << endl;
	cout << "L2:  ";
	L2.display();

	cout << endl;
	cout << "L3:  ";
	L3.display();

	getchar();
	return 0;
}