
#include <iostream>
using namespace std;
struct node
{
	int data;
	node *next;
};

class LinkedList
{
private:
	node *head, *tail; // node type variables
public:
	LinkedList() //constructor
	{
		head = NULL;
		tail = NULL;
	}

	void CreateNode(int number)
	{
		node *temp = new node; //temp is object of node type
		temp->data = number;
		temp->next = NULL;
		if (head == NULL)
		{
			head = temp;
			tail = temp;
			temp = NULL;
		}
		else
		{
			tail->next = temp;
			tail = temp;
		}
	}


	//insert at start
	void InsertStart()
	{
		int number;
		cout << "\nEnter value: ";
		cin >> number;


		node *temp = new node;
		temp->data = number;
		temp->next = head;
		head = temp;
	}

	//Function to insert at the end
	void InsertLast()
	{
		int number;
		cout << "\nEnter value: ";
		cin >> number;
		node *temp = new node;
		temp->data = number;
		temp->next = NULL;

		if (head == NULL)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			tail->next = temp;
			tail = tail->next;
		}
	}

	//function to insert node in between of list
	void InsertParticular()
	{
		int positn;
		int value;
		cout << "Enter position where to insert: ";
		cin >> positn;
		if (positn <= length()){
			cout << "Enter value: ";
			cin >> value;

			node *temp = new node;
			node *current = new node;
			node *prev = new node;

			current = head;

			for (int counter = 1; counter < positn; counter++) {
				prev = current;
				current = current->next;
			}

			temp->data = value;
			prev->next = temp;
			temp->next = current;
		}
		else{
			cout << "\n~~out of bound input~~" << endl;
		cout << "Length of list is: " << length() <<endl;
		}
	}

	//function to delete first node
	void deleteBegin()
	{
		node *temp = new node;
		temp = head;
		head = head->next;
		delete temp;
	}

	//function to delete last node
	void deleteLast()
	{
		node *current = new node;
		node *prev = new node;
		current = head;
		while (current->next != NULL)
		{
			prev = current;
			current = current->next;
		}
		tail = prev;
		prev->next = NULL;
		delete current;
	}

	//function to delete particular node of list
	void deletePart()
	{

		int pos;
		cout << "Enter position where to delete: ";
		cin >> pos;
		if (pos <= length()){
		node *current = new node;
		node *prev = new node;
		current = head;
		for (int i = 1; i < pos; i++)
		{
			prev = current;
			current = current->next;
		}
		prev->next = current->next;
		}
	else{
			cout << "\n~~out of bound input~~" << endl;
			cout << "Length of list is: " << length() << endl;
		}

	}


	// function to display
	void display()
	{
		node *temp = new node;
		temp = head;
		if (temp == NULL){
			cout << "Nothing to display";
		}
		while (temp != NULL)
		{
			cout << temp->data << "\t";
			temp = temp->next;
		}
	}

	void ReverseList()
	{
		if (head == NULL) return;

		node *prev = NULL, *current = NULL, *next = NULL;
		current = head;
		while (current != NULL) {
			next = current->next;
			current->next = prev;
			prev = current;
			current = next;
		}
		head = prev;
	}



	void search(){
		int num;
		cout << "\n Enter value to search: ";
		cin >> num;
		int count = 1;
		node *temp = new node();
		temp = head;

		while (temp != NULL){

			if (temp->data == num){
				cout << "The element found on " << count << " position";
				return;
			}
			temp = temp->next;
			count++;
		}

		cout << "The element is not in list.";
	}

	void DestroyList(){

		node *temp = new node();
		node* current = head;

		while (current != NULL)
		{
			if (current == NULL)
				break;
			else
			{
				temp = current;
				current = current->next;
				delete temp;
			}
		}
		head = NULL;
	}

	int length(){
		node *temp = new node();
		temp = head;
		int count = 1;
		
		while (temp->next != NULL){
			temp = temp->next;
			count++;
		}
		return count;
	}

};

//main function
int main()
{
	LinkedList object;
	int elements;
	int value;
	int choice;
	char cchoice;
	int loopv = 1;
	cout << "~~Menu for Linked List~~" << endl;
	cout << "How many elements do you want to insert in a list:  ";
	cin >> elements;
	cout << "\n enter elements of the list:  ";
	for (int w = 1; w <= elements; w++){
		cin >> value;
		object.CreateNode(value);
	}

	cout << endl << object.length();
	while (loopv != 0){
		cout << "\nChose any one operation to perform:" << endl;
		cout << "1) Insert Elements: " << endl
			<< "2) Delete Nodes" << endl
			<< "3) Search specific element" << endl
			<< "4) Traverse list" << endl
			<< "5) Destroy list" << endl
			<< "6) Display list" << endl
			<< "7) Exit program" << endl;
		cout << "\n Enter your choice:  ";
		cin >> choice;
		switch (choice){
		case 1:
			cout << "~Insertion part~" << endl
				<< "a) insert at start" << endl
				<< "b) insert at last" << endl
				<< "c) insert at specific position" << endl
				<< "Your choice:  ";
			cin >> cchoice;
			switch (cchoice){
			case 'a':
				object.InsertStart();
				break;
			case 'b':
				object.InsertLast();
				break;
			case 'c':
				object.InsertParticular();
				break;
			default:
				cout << "incorrent input";
				break;
			}
			break;
		case 2:
			cout << "~Deletion part~" << endl
				<< "a) delete start" << endl
				<< "b) delete last" << endl
				<< "c) delete specific position" << endl
				<< "Your choice:  ";
			cin >> cchoice;
			switch (cchoice){
			case 'a':
				object.deleteBegin();
				break;
			case 'b':
				object.deleteLast();
				break;
			case 'c':
				object.deletePart();
				break;
			default:
				cout << "incorrent input";
				break;
			}


			break;  //exit case 2
		case 3:
			object.search();
			break;
		case 4:
			object.ReverseList();
			break;
		case 5:
			object.DestroyList();
			break;
		case 6:
			object.display();
			break;
		case 7:
			loopv = 0;
			break;
		default:
			cout << "wrong input";

		}
		cout << endl<<endl;
	}
	getchar();
	getchar();
	return 0;
}