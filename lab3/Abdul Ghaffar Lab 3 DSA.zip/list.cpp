/*
	Name:   Abdul Ghaffar Kalhoro
	Registration:  194699
	Class:  BSCS-6c 
	Lab 3  Data structures and algorithms


*/

#include<iostream>
using namespace std;

//creating node structure
struct node{
	int data;
	node *next;

};

//class for list
class list{

private:
	node *head, *tail;

public:
	list()   //list class constructor
	{  
		head = NULL;
		tail = NULL;
	}

	void createnode(int value)   //function for creating node.
	{
		node *temp = new node;
		list *object = new list;
		temp->data = value;
		temp->next = NULL;
		if (head == NULL)
		{
			head = temp;
			tail = temp;
			temp = NULL;
		}
		else
		{
			tail->next = temp;
			tail = temp;
		}
	}
	void display()   //function display
	{
		node *tempc = new node;
		tempc = head;
		while (tempc != NULL)  //traversing the list elements
		{
			cout << tempc->data << "\t";
			tempc = tempc->next;
		}
	}

	int addition()   //addition function for adding elements.
	{
		int add=0;
		node *temp = new node;
		temp = head;
		
		while (temp != NULL)
		{
			add = add + temp->data;
			temp = temp->next;
		}
		return add;
	
	}


};   //end class list


int main()
{
	list object;
	char condition;
	int number, list_ele;

	cout << "Do you want to create node (Y/N)  :  ";
	cin >> condition;   //taking input for user agreement

	if (condition == 'Y'){
	
		cout << "How many elements do you want to store: ";
		cin >> number;  //taking input and storing in number

		cout << "Enter your numbers: ";
		for (int counter=1;counter<=number;counter++)//for loop for taking user input and creating nodes. 
		{
			cin >> list_ele;
			object.createnode(list_ele);  //calling the function of createnode

		}
		cout << "Your entered linked list elements are: ";
		object.display();	//calling function display
		cout << "\nThe addition of all numbers is: "<< object.addition();
	}
	else if (condition == 'N'){
		cout << "Thanks for using!! ";
	}
	else{
		cout << "Wrong pattern entered.";
		}

	getchar();
	getchar();
	return 0;

}	//end main function
